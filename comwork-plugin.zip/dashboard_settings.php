<?php

register_activation_hook( __FILE__, 'comwork_set_default_options' );

add_action( 'admin_init', 'comwork_api_admin_init' );

add_action( 'admin_menu', 'comwork_api_settings_menu' );


function comwork_set_default_options() {
  comwork_get_options();
}

function comwork_get_options() {
  $options = get_option( 'comwork_api_options', array() );

  $new_options['comwork_client_id'] = '';
  $new_options['comwork_client_secret'] = '';

  $merged_options = wp_parse_args( $options, $new_options );

  $compare_options = array_diff_key( $new_options, $options );
  if ( empty( $options ) || !empty( $compare_options ) ) {
      update_option( 'comwork_api_options', $merged_options );
  }
  return $merged_options;
}


function comwork_api_admin_init() {
  // Register a setting group with a validation function
  // so that post data handling is done automatically for us 
  register_setting( 'comwork_api_settings',
      'comwork_api_options', 'comwork_api_validate_options' );

  // Add a new settings section within the group
  add_settings_section( 'comwork_api_main_section', 'Main Settings',
      'comwork_api_main_setting_section_callback',
      'comwork_api_settings_section' );
  // Add each field with its name and function to use for
  // our new settings, put them in our new section 
  
  add_settings_field( 'comwork_client_id',
    'Comwork Client ID', 'comwork_display_client_id',
    'comwork_api_settings_section', 'comwork_api_main_section',
    array( 'name' => 'comwork_client_id' ) );

  add_settings_field( 'comwork_client_secret',
    'Comwork Client Secret', 'comwork_display_client_secret',
    'comwork_api_settings_section', 'comwork_api_main_section',
    array( 'name' => 'comwork_client_secret' ) );
}

function comwork_api_validate_options( $input ) {
  foreach ( array( 'comwork_client_id' ) as $option_name ) {
    if ( isset( $input[$option_name] ) ) {
      $input[$option_name] = sanitize_text_field( $input[$option_name] );
    }
  }
  foreach ( array( 'comwork_client_secret' ) as $option_name ) {
    if ( isset( $input[$option_name] ) ) {
      $input[$option_name] = sanitize_text_field( $input[$option_name] );
    }
  }
  return $input;  
}

function comwork_api_main_setting_section_callback() { ?>
  <p>This is the main configuration section.</p>
<?php }

function comwork_display_client_secret( $data = array() ) {
  extract( $data );
  $options = comwork_get_options();
  ?>
  <input type="text" name="comwork_api_options[<?php echo $name; ?>]"
         value="<?php echo esc_html( $options[$name] ); ?>"/>
  <br />
<?php }


function comwork_display_client_id( $data = array() ) {
  extract( $data );
  $options = comwork_get_options();
  ?>
  <input type="text" name="comwork_api_options[<?php echo $name; ?>]"
         value="<?php echo esc_html( $options[$name] ); ?>"/>
  <br />
<?php }


function comwork_api_settings_menu() {
  add_options_page( 'Comwork API Configuration',
      'Comwork - API', 'manage_options',
      'comwork-api-settings', 'comwork_api_config_page' );
}

function comwork_api_config_page() { ?>
  <div id="comwork_api-general" class="wrap">
  <h2>Comwork - Settings API</h2>
  <form name="comwork_api_options_form_settings_api" method="post"
        action="options.php">
  <?php settings_fields( 'comwork_api_settings' ); ?>
  <?php do_settings_sections( 'comwork_api_settings_section' ); ?>
  <input type="submit" value="Submit" class="button-primary" />
  </form></div>
<?php }
