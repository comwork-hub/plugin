<?php
/**
 * Plugin Name: Comwork Plugin
 */

require 'dashboard_settings.php';


function log_in_to_comwork() {
  $the_options = comwork_get_options();
  $client_id = $the_options['comwork_client_id'];
  $client_secret = $the_options['comwork_client_secret'];
  
  $url = 'https://museum.comwork.eu/oauth/token?grant_type=client_credentials&scope=read';
  $url .= '&client_id=' . $client_id . '&client_secret=' . $client_secret; 

  $response = wp_remote_post($url);
  $body = wp_remote_retrieve_body($response);

  return json_decode ( $body, true );
}


//------------------------------------------------------------------------------------------------
/**
 * [catalogo]
 * [catalogo type="collezione"]
 * [catalogo type="percorso"]
 * [catalogo type="tema"]
 * [catalogo titolo="titolo"]
 */
//[catalogo type="collezione"]
add_shortcode( 'catalogo', 'catalogo_func' );

/**
 * Crea shortcode [catalogo]
 * La funzione controlla il tipo di permalink inspostato nel sito wordpress, 
 * e passa questa informazione al frontend. Serve per evitare alcuni bug quando il 
 * permalink plain e impostato.
 * Prende dal sito l'url della rest api di wordpress, e passa questa informazione al frontend.
 */
function catalogo_func( $atts = [], $content = null, $tag = '' ) {
  // normalize attribute keys, lowercase
  $atts = array_change_key_case((array)$atts, CASE_LOWER);
  // override default attributes with user attributes
  $wporg_atts = shortcode_atts([
                                  'tipologia' => '',
                                  'titolo'   => '',
                                ], $atts, $tag);
  $catalogo_type = $wporg_atts['tipologia'];
  $catalogo_titolo = $wporg_atts['titolo'];
  $permalink = "FALSE";
  if ( get_option('permalink_structure') ) {
    $permalink = "TRUE";
  }
  $site_url = get_rest_url();
  
  $new_content = '<script>var permalink =' . json_encode( $permalink, JSON_HEX_TAG )  . ';</script>';
  $new_content .= '<script>var siteUrl =' . json_encode( $site_url, JSON_HEX_TAG )  . ';</script>';
  $new_content .= '<script>var catalogo_type =' . json_encode( $catalogo_type, JSON_HEX_TAG )  . ';</script>';
  $new_content .= '<script>var catalogo_titolo =' . json_encode( $catalogo_titolo, JSON_HEX_TAG )  . ';</script>';


  $new_content .= '<div id="root"></div>';
  $bundle1 = file_get_contents(plugins_url('/dist/bundle.js', __FILE__));

  $new_content .= '<script>' . $bundle1 . '</script>';

  return $new_content;
}

/**
 * Prende la lista delle collezioni 
 */

function get_comwork_collections( $request ) {
  $credentials = log_in_to_comwork();
  $access_token = $credentials['access_token'];
  $token_type = $credentials['token_type'];
  $url = 'https://museum.comwork.eu/public/api/catalogue/collections';
  if (isset( $request['size'] )) {
    $url .= '?size=' . $request['size'];
  } else {
    $url .= '?size=100';
  }
  if (isset( $request['type'] )) {
    $url .= '&type=' . $request['type'];
  }
  $args = array(
    'headers' => array( 'Authorization' => $token_type . ' ' . $access_token ),
    'timeout' => 20
  );
  $response = wp_remote_get($url, $args);
  return json_decode ( wp_remote_retrieve_body( $response ), true);
}

/**
 * Prende il contenuto della collezione
 */
function get_comwork_collections_dettails( $data ) {
  $credentials = log_in_to_comwork();
  $access_token = $credentials['access_token'];
  $token_type = $credentials['token_type'];
  $endUrl = $data['id'];
  if (isset($data['size'])) {
    $endUrl .= '?size=' . $data['size'];
  } else {
    $endUrl .= '?size=20';
  }
  if (isset($data['page'])) {
    $endUrl .= '&page=' . $data['page'];
  } else {
    $endUrl .= '&page=0';
  }
  $url = 'https://museum.comwork.eu/public/api/catalogue/collections/' . $endUrl;
  $args = array(
    'headers' => array( 'Authorization' => $token_type . ' ' . $access_token ),
    'timeout' => 20
  );
  $response = wp_remote_get($url, $args);
  return json_decode ( wp_remote_retrieve_body( $response ), true);
}

/**
 * Responsabile della ricerca avvanzata, ordinamento, sort
 */
function get_comwork_catalogue( $request ) {
  $credentials = log_in_to_comwork();
  $access_token = $credentials['access_token'];
  $token_type = $credentials['token_type'];
  
  $url = set_comwork_request_url( $request );
  
  $args = array(
    'headers' => array( 'Authorization' => $token_type . ' ' . $access_token ),
    'timeout' => 20
  );
  $response = wp_remote_get($url, $args);
  return json_decode ( wp_remote_retrieve_body( $response ), true);
}

/**
 * Costruisce l'url con tutti i parametri
 */
function set_comwork_request_url( $request ) {
  $url = 'https://museum.comwork.eu/public/api/catalogue';
  $query = '';
  if ( isset($request['text']) ) {
    $query = '?q=' . $request['text'];
  }
  elseif ( isset($request['artist']) ) {
    $query = '/search?artist=' . $request['artist'];
  } elseif ( isset($request['culture']) ) {
    $query = '/search?culture=' . $request['culture'];
  } elseif ( isset($request['title']) ) {
    $query = '/search?title=' . $request['title'];
  } elseif ( isset($request['historicDescription']) ) {
    $query = '/search?historicDescription=' . $request['historicDescription'];
  } elseif ( isset($request['location']) ) {
    $query = '/search?location=' . $request['location'];
  } elseif ( isset($request['objectNumber']) ) {
    $query = '/search?objectNumber=' . $request['objectNumber'];
  }

  if ( isset($request['size']) ) {
    if ( $query == '' ) {
      $query = '?size=' . $request['size'];
    } else {
      $query .= '&size=' . $request['size'];
    }
  }
  if ( isset($request['page'])  ) {
    if ( $query == '' ) {
      $query = '?page=' . $request['page'];
    } else {
      $query .= '&page=' . $request['page'];
    }
  }
  
  if ( isset($request['sort']) ) {
    if ( $query == '' ) {
      $query = '?sort=' . $request['sort'];
    } else {
      $query .= '&sort=' . $request['sort'];
    }
  }
  if ( isset($request['order']) ) {
    if ( $query == '' ) {
      $query = '?order=' . $request['order'];
    } else {
      $query .= '&order=' . $request['order'];
    }
  }

  if ( isset($request['department']) ) {
    if ( $query == '' ) {
      $query = '?department=' . $request['department'];
    } else {
      $query .= '&department=' . $request['department'];
    }
  }
  if ( isset($request['object_name']) ) {
    if ( $query == '' ) {
      $query = '?object_name=' . $request['object_name'];
    } else {
      $query .= '&object_name=' . $request['object_name'];
    }
  }
  if ( isset($request['material']) ) {
    if ( $query == '' ) {
      $query = '?material=' . $request['material'];
    } else {
      $query .= '&material=' . $request['material'];
    }
  }
  if ( isset($request['date']) ) {
    if ( $query == '' ) {
      $query = '?date=' . $request['date'];
    } else {
      $query .= '&date=' . $request['date'];
    }
  }

  $url .= $query;
  return $url;
}
#----------------------------------------------------------------------------------------------------

function collections_dettails_request_arguments() {
  $args = array();

  $args['size'] = array(
    'description' => esc_html__('Blocksize of response', 'my-text-domain'),
    'type'        => 'string',
  );
  $args['page'] = array(
    'description' => esc_html__('Page number', 'my-text-domain'),
    'type'        => 'string',
  );
}

function collections_get_request_arguments() {
  $args = array();

  $args['type'] = array(
    'description' => esc_html__( 'Get by collection type', 'my-text-domain' ),
    'type'        => 'string',
  );
    // size related arguments
    $args['size'] = array(
      'description' => esc_html__( 'The size parameter is used to specify the blocksize of response', 'my-text-domain' ),
      'type'        => 'string',
      //'enum'        => array( '20', '40', '80', ),
    );
    $args['page'] = array(
      'description' => esc_html__( 'The page parameter is used to specify the page number',  'my-text-domain' ),
      'type'        => 'string',
    );
  
  
}

/**
 * We can use this function to contain our arguments for the example product endpoint.
 */
function prefix_get_request_arguments() {
  $args = array();

  // Search arguments
  $args['text'] = array(
      'description' => esc_html__( 'The text parameter is used to make general search', 'my-text-domain' ),
      'type'        => 'string',
  );
  $args['artist'] = array(
    'description' => esc_html__( 'Search by artist name', 'my-text-domain' ),
    'type'        => 'string',
  );
  $args['culture'] = array(
    'description' => esc_html__( 'Search by culture type', 'my-text-domain' ),
    'type'        => 'string',
  );
  $args['title'] = array(
    'description' => esc_html__( 'Search by title', 'my-text-domain' ),
    'type'        => 'string',
  );
  $args['historicDescription'] = array(
    'description' => esc_html__( 'Search by description', 'my-text-domain' ),
    'type'        => 'string',
  );
  $args['location'] = array(
    'description' => esc_html__( 'Search by location', 'my-text-domain' ),
    'type'        => 'string',
  );
  $args['objectNumber'] = array(
    'description' => esc_html__( 'Search by object number', 'my-text-domain' ),
    'type'        => 'string',
  );

  // size related arguments
  $args['size'] = array(
    'description' => esc_html__( 'The size parameter is used to specify the blocksize of response', 'my-text-domain' ),
    'type'        => 'string',
    //'enum'        => array( '20', '40', '80' ),
  );
  $args['page'] = array(
    'description' => esc_html__( 'The page parameter is used to specify the page number',  'my-text-domain' ),
    'type'        => 'string',
  );

  // sort related arguments
  $args['sort'] = array(
    'description' => esc_html__( 'Sort the result', 'my-text-domain' ),
    'type'        => 'string',
    'enum'        => array( 'relevance', 'title', 'objectAuthor.name_sort', 'dateFrom_sort', 'objectNumbers.objectNumber_sort' ),
  );
  $args['order'] = array(
    'description' => esc_html__( 'Order of the sort', 'my-text-domain' ),
    'type'        => 'string',
    'enum'        => array( 'ASC', 'DESC' ),
  );

  // filter arguments
  $args['department'] = array(
    'description' => esc_html__( 'Filter by department name', 'my-text-domain' ),
    'type'        => 'string',
  );
  $args['object_name'] = array(
    'description' => esc_html__( 'Filter by object type', 'my-text-domain' ),
    'type'        => 'string',
  );
  $args['material'] = array(
    'description' => esc_html__( 'Filter by materila type', 'my-text-domain' ),
    'type'        => 'string',
  );
  $args['date'] = array(
    'description' => esc_html__( 'Filter by date/era', 'my-text-domain' ),
    'type'        => 'string',
  );
  return $args;
}


function get_comwork_object_dettails( $data ) {
  $credentials = log_in_to_comwork();
  $access_token = $credentials['access_token'];
  $token_type = $credentials['token_type'];
  $url = 'https://museum.comwork.eu/public/api/catalogue/' . $data['id'];
  $args = array(
    'headers' => array( 'Authorization' => $token_type . ' ' . $access_token ),
    'timeout' => 20
  );
  $response = wp_remote_get($url, $args);
  return json_decode ( wp_remote_retrieve_body( $response ), true);
}

add_action( 'rest_api_init', function () {
  
  register_rest_route( 'comwork/v1', '/catalogue/(?P<id>\d+)', array(
    'methods' => 'GET',
    'callback' => 'get_comwork_object_dettails',
  ) );
  register_rest_route( 'comwork/v1', '/collections', array(
    'methods' => 'GET',
    'callback' => 'get_comwork_collections',
    'args' => collections_get_request_arguments(),
  ) );
  register_rest_route( 'comwork/v1', '/collections/(?P<id>\d+)', array(
    'methods' => 'GET',
    'callback' => 'get_comwork_collections_dettails',
    'args' => collections_dettails_request_arguments(),
  ) );
  register_rest_route( 'comwork/v1', '/catalogue', array(
    'methods' => 'GET',
    'callback' => 'get_comwork_catalogue',
    'args' => prefix_get_request_arguments(),
  ) );
} );

